@extends('layouts.main')

@section('content')
    <div class="row my-5">
        <h1 class="text-white">Halaman Home</h1>
    </div>
@endsection

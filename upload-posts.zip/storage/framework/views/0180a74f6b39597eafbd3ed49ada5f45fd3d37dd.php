<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="links">
            
            <?php if($paginator->onFirstPage()): ?>
                <li aria-disabled="true" class="me-2" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span aria-hidden="true">&lsaquo; Prev</span>
                </li>
            <?php else: ?>
                <li>
                    <a class="next" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&lsaquo; Prev</a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li class="pageNumber disabled" aria-disabled="true"><span class="page-link"><?php echo e($element); ?></span></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="pageNumber active" aria-current="page"><a href="#"><?php echo e($page); ?></a></li>
                    <?php else: ?>
                        <li class="pageNumber"><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a class="next" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">Next &rsaquo;</a>
                </li>
            <?php else: ?>
                <li aria-disabled="true" class="ms-2" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span aria-hidden="true">Next &rsaquo;</span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>

<?php /**PATH D:\appLaravel\funCode\resources\views/layouts/my-paginate.blade.php ENDPATH**/ ?>
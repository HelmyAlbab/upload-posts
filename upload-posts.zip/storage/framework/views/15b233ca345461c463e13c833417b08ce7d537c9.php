

<?php $__env->startSection('content'); ?>
    <div class="row my-5">
        <h2 class="mb-4">Posts Category : <?php echo e($category); ?></h2>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="mb-3">
                <h2><a class="text-decoration-none" href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h2>
                <p><?php echo e($post->excerpt); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/category.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="row my-5">

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <h2 class="mb-3 text-white"><?php echo e($post->title); ?></h2>
                    <p class="text-white">
                        By: <a style="color: #37beb0" class="text-decoration-none" href="/posts?author=<?php echo e($post->author->username); ?>"><?php echo e($post->author->name); ?></a> in <a style="color: #37beb0" class="text-decoration-none" href="/posts?category=<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
                    </p>

                    <img class="img-fluid" src="https://source.unsplash.com/900x400/?<?php echo e($post->category->name); ?>" alt="<?php echo e($post->category->name); ?>">
                    <article class="my-3 fs-5 text-white">
                        <?php echo $post->body; ?>

                    </article>
                    <a style="background: #37beb0;color: #fff" class="btn mt-4" href="/posts">Kembali ke Posts</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/post.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <?php if(session()->has('berhasil')): ?>
        <div class="alert alert-success alert-dismissible fade show lh-sm mx-5 my-3" role="alert">
            <?php echo e(session('berhasil')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('update')): ?>
        <div class="alert alert-warning alert-dismissible fade show lh-sm mx-5 my-3" role="alert">
            <?php echo e(session('update')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('hapus')): ?>
        <div class="alert alert-danger alert-dismissible fade show lh-sm mx-5 my-3" role="alert">
            <?php echo e(session('hapus')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="mx-5 my-2 text-uppercase fs-2 fw-bold">Post Category</div>
    <div class="mx-5 my-4">
        <a href="/dashboard/categories/create" class="btn btn-success mb-3">Create new category</a>
        <table id="example" class="display nowrap" style="width:100%">
            <thead>
                <tr>
                    <th width="20px">No</th>
                    <th width="400px">Category Name</th>
                    <th width="200px">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td class="tabelIcons">
                            <a href="/dashboard/categories/<?php echo e($category->id); ?>/edit" class="btn btn-warning"><ion-icon name="pencil-outline"></ion-icon></a>
                            <form action="/dashboard/categories/<?php echo e($category->id); ?>" method="post" class="d-inline">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger tombol" onclick="return confirm('are you sure?')"><ion-icon name="trash-outline"></ion-icon></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>
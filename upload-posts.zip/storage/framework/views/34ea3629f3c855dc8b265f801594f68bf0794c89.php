

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('berhasil')): ?>
        <div class="alert alert-success alert-dismissible fade show lh-sm mx-5 my-3" role="alert">
            <?php echo e(session('berhasil')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('update')): ?>
        <div class="alert alert-warning alert-dismissible fade show lh-sm mx-5 my-3" role="alert">
            <?php echo e(session('update')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('hapus')): ?>
        <div class="alert alert-danger alert-dismissible fade show lh-sm mx-5 my-3" role="alert">
            <?php echo e(session('hapus')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="mx-5 my-2 text-uppercase fs-2 fw-bold">Upload Posts</div>
    <div class="mx-5 my-4">
        <a href="/dashboard/posts/create" class="btn btn-success mb-3">Create new post</a>
        <table id="example" class="display nowrap" style="width:100%">
            <thead>
                <tr>
                    <th width="20px">No</th>
                    <th width="260px">Title</th>
                    <th width="260px">Category</th>
                    <th width="200px">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->category->name ?? 'None'); ?></td>
                        <td class="tabelIcons">
                            <a href="/dashboard/posts/<?php echo e($post->slug); ?>" class="btn btn-info"><ion-icon name="eye-outline"></ion-icon></a>
                            <a href="/dashboard/posts/<?php echo e($post->slug); ?>/edit" class="btn btn-warning"><ion-icon name="pencil-outline"></ion-icon></a>
                            <form action="/dashboard/posts/<?php echo e($post->slug); ?>" method="post" class="d-inline">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger tombol" onclick="return confirm('are you sure?')"><ion-icon name="trash-outline"></ion-icon></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/dashboard/posts/index.blade.php ENDPATH**/ ?>
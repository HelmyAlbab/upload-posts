

<?php $__env->startSection('content'); ?>
    <div class="row my-5">
        <h1 class="text-white">Halaman Home</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/home.blade.php ENDPATH**/ ?>
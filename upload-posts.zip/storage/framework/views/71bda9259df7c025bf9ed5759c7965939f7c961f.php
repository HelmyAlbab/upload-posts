

<?php $__env->startSection('content'); ?>
    <div class="row my-5">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <a href="/posts?category=<?php echo e($category->slug); ?>">
                        <div class="card bg-dark text-white border-0">
                            <img src="https://source.unsplash.com/500x400?<?php echo e($category->name); ?>" class="card-img" alt="<?php echo e($category->name); ?>">
                            <div class="card-img-overlay d-flex align-items-center p-0">
                                <h3 class="card-title text-center flex-fill p-4" style="color: rgb(255, 255, 255);background:rgba(0,0,0,0.5)"><?php echo e($category->name); ?></h3>
                            </div>
                        </div>
                    </a>
                </div>       
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/postsFolder/categories.blade.php ENDPATH**/ ?>
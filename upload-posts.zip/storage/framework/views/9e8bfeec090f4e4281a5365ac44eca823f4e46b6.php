

<?php $__env->startSection('content'); ?>
<section class="my-5">
    <div class="box">
        <div class="form">
            <h3>Please Registration</h3>
            <form action="/register" method="post">
                <?php echo csrf_field(); ?>
                <div class="inputBx">
                    <input type="text" name="username" placeholder="Username" required value="<?php echo e(old('username')); ?>" autofocus>
                    <ion-icon name="person"></ion-icon>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="text" name="name" placeholder="Nama" required value="<?php echo e(old('name')); ?>">
                    <ion-icon name="person-circle"></ion-icon>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="email" name="email" placeholder="Email" required value="<?php echo e(old('email')); ?>">
                    <ion-icon name="mail"></ion-icon>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="phone" name="phone" placeholder="Phone" required value="<?php echo e(old('phone')); ?>">
                    <ion-icon name="call-outline"></ion-icon>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="password" name="password" placeholder="Password" required>
                    <ion-icon name="lock-closed"></ion-icon>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="submit" value="Register">
                </div>
            </form>
            <p>Already have account? Please <a href="/login">login</a></p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/loginRegister/register.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="container">
            <div class="row mx-3 col-lg-12">
                <div class="col-lg-8">
                    <h2 class="mb-3 text-dark"><?php echo e($post->title); ?></h2>
                    <a href="/dashboard/posts" class="btn text-white mb-3" style="background: #37beb0;">Back to my all posts</a>
                    <a href="/dashboard/posts/<?php echo e($post->slug); ?>/edit" class="btn text-white btn-warning mb-3">Edit</a>
                    <form action="/dashboard/posts/<?php echo e($post->slug); ?>" method="post" class="d-inline mb-3">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-danger mb-3" onclick="return confirm('are you sure?')">Delete</button>
                    </form>

                    <?php if($post->image): ?>
                        <div style="max-height: 350px; overflow:hidden;">
                            <img class="img-fluid" src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->category->name ?? 'None'); ?>">
                        </div>
                    <?php else: ?>
                        <img class="img-fluid" src="https://source.unsplash.com/900x400/?<?php echo e($post->category->name ?? 'None'); ?>" alt="<?php echo e($post->category->name ?? 'None'); ?>">
                    <?php endif; ?>
                    <article class="my-3 fs-5 text-dark">
                        <?php echo $post->body; ?>

                    </article>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/dashboard/posts/show.blade.php ENDPATH**/ ?>
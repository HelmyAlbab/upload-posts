

<?php $__env->startSection('content'); ?>
<section>
    <div class="box">
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show lh-sm" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show lh-sm" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="form">
            <h3>Please Login</h3>
            <form action="/login" method="post">
                <?php echo csrf_field(); ?>
                <div class="inputBx">
                    <input type="text" name="username" id="username" placeholder="Username" required value="<?php echo e(old('username')); ?>" autofocus>
                    <ion-icon name="person"></ion-icon>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="password" name="password" name="password" placeholder="Password" required>
                    <ion-icon name="lock-closed"></ion-icon>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger p-0 lh-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="inputBx">
                    <input type="submit" value="Login">
                </div>
            </form>
            <p>Not a member? Please <a href="/register">register</a></p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/loginRegister/login.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <div class="row my-5">
        <h2 class="mb-4"><?php echo e($title); ?></h2>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul class="list-group col-lg-6">
                <li class="list-group-item"><h3 class="text-center"><a class="text-decoration-none" href="/authors/<?php echo e($user->username); ?>"><?php echo e($user->name); ?></a></h3>
                </li>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\appLaravel\funCode\resources\views/authors.blade.php ENDPATH**/ ?>